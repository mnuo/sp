package com.mnuo.bpk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * number 
 *
 */
@SpringBootApplication
@EnableEurekaServer
public class BpkRegisterServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(BpkRegisterServiceApplication.class, args);
	}
}
