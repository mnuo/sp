package com.mnuo.bpk.consumer.api;

import org.springframework.stereotype.Component;

@Component
public class FeignApiFallBack implements FeignApi {

	@Override
	public String sayHello() {
		 return "Hello！visit provices fail";
	}

}
