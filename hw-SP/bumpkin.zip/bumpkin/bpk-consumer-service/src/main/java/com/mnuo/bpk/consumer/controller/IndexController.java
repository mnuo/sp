package com.mnuo.bpk.consumer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mnuo.bpk.consumer.api.FeignApi;

@RestController
public class IndexController {
	
	@Autowired(required = false)
    private FeignApi feignApi;
 
    /*
     * @ClassName FeignController
     * @Desc TODO   调用 Say Hello 方法
     * @Date 2019/5/15 16:20
     * @Version 1.0
     */
    @RequestMapping("/feign")
    public String feign(){
        return feignApi.sayHello();
    }
}
