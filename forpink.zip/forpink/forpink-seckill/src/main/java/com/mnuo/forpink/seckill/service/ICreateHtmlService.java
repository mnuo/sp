package com.mnuo.forpink.seckill.service;

import com.mnuo.forpink.seckill.common.Result;

/**
 * 生成商品静态页
 * 创建者  小柒2012
 */
public interface ICreateHtmlService {
	Result createAllHtml();
}
