package com.mnuo.forpink.seckill;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Hello world!
 *
 */
@SpringBootApplication
public class ForpinkSeckillApplication {
	public static void main(String[] args) {
		SpringApplication.run(ForpinkSeckillApplication.class, args);
		System.out.println("启动成功");
	}
}
