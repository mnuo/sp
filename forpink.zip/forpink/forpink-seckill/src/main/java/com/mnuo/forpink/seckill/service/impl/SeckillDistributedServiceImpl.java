package com.mnuo.forpink.seckill.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mnuo.forpink.seckill.common.Result;
import com.mnuo.forpink.seckill.common.dynamicquery.DynamicQuery;
import com.mnuo.forpink.seckill.service.ISeckillDistributedService;
@Service
public class SeckillDistributedServiceImpl implements ISeckillDistributedService {
	
	@Autowired
	private DynamicQuery dynamicQuery;

	@Override
	public Result startSeckilRedisLock(long seckillId, long userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result startSeckilZksLock(long seckillId, long userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result startSeckilLock(long seckillId, long userId, long number) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
